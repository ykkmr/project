package Admin;

public class ServiceAdminDAO {

}//class
