package LookBookComment;

public class ServiceLBCommentDAO {

}//class
